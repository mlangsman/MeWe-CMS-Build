<p><?=lang('total_referrers')?> <?=$num_referrers?></p>
<div class="clear_left"></div>