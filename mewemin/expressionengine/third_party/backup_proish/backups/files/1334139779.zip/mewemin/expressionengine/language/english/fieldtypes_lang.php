<?php

$lang = array(

'add_file'	=>
'Add File',

'remove_file' =>
'Remove File',

'directory_no_access' =>
'You do not have access to the directory specified for this field',

'directory' =>
'Directory:',

// IGNORE
''=>'');
/* End of file fieldtypes_lang.php */
/* Location: ./system/expressionengine/language/english/fieldtypes_lang.php */